import {ReactNode} from 'react';

export interface PortalProviderProps {
  children: ReactNode | ReactNode[];
}
