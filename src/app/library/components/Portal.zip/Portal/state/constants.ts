// eslint-disable-next-line no-shadow
enum ACTIONS {
  REGISTER_HOST,
  UN_REGISTER_HOST,
  ADD_PORTAL,
  UPDATE_PORTAL,
  REMOVE_PORTAL,
}
const INITIAL_STATE = {};
export {ACTIONS, INITIAL_STATE};
